//인터페이스는 설계도, 작업지시서
//public 과 abstract 개념
public interface Wearable {
  
  void putOn();
  void putOff();

}

//1. 인스턴스는 생성할 수 없다.